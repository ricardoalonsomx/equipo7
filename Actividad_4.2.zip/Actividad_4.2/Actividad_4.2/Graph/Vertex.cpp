//
//  Vertex.cpp
//  Graph
//
//  Created by Vicente Cubells on 10/11/20.
//

#include "Vertex.hpp"
